# Build Android Debug APK - 3 Simple Steps

## ⚡ Quick Build (< 2 minutes)

### Step 1: Extract the project
```bash
unzip arrows-libgdx-project.zip
cd arrows-libgdx-project
```

### Step 2: Build the APK
```bash
# On macOS/Linux
./gradlew android:assembleDebug

# On Windows
gradlew.bat android:assembleDebug
```

### Step 3: Find your APK
```
android/build/outputs/apk/debug/android-debug.apk
```

**That's it!** The APK is ready to install.

---

## 📱 Installing on Your Phone

### Option A: USB Cable (Fastest)
```bash
# Connect phone via USB, enable USB debugging
./gradlew android:installDebug
./gradlew android:run

# Game starts automatically!
```

### Option B: Manual Installation
1. Build APK: `./gradlew android:assembleDebug`
2. Find APK: `android/build/outputs/apk/debug/android-debug.apk`
3. Email/transfer to phone
4. Open file manager on phone → tap APK → Install

### Option C: ADB (Advanced)
```bash
# Connect phone via USB
adb devices                              # Verify device
adb install android/build/outputs/apk/debug/android-debug.apk
adb shell am start com.arrows.game/com.arrows.game.AndroidLauncher
```

---

## ✅ Minimum Requirements

- **Java**: `java -version` must show 11 or higher
- **USB Debugging**: Enabled on phone (Settings → Developer Options)
- **USB Driver**: Windows only (usually installed automatically)

---

## 🚀 Build Times

| Build | Time | Notes |
|-------|------|-------|
| First Build | 3-5 min | Downloads all dependencies |
| Subsequent | 30-60 sec | Very fast |
| First Install | 20-30 sec | Over USB |

---

## 🐛 Troubleshooting

### "gradle command not found"
```bash
chmod +x gradlew
./gradlew android:assembleDebug
```

### "Java not found"
Install JDK 11+: https://adoptopenjdk.net

### "Device not found" (ADB)
```bash
# Windows: Install drivers
# Linux: sudo apt-get install android-tools-adb
# macOS: brew install android-platform-tools

adb devices  # Should list your phone
```

### Build hangs
```bash
# Kill daemon and restart
./gradlew --stop
./gradlew android:assembleDebug
```

---

## 📂 APK Location

After building successfully, find your APK at:

**`android/build/outputs/apk/debug/android-debug.apk`**

File size: ~30 MB (debug build)

---

## 🎮 What to Expect

**When you run the APK:**
- Dark blue screen appears
- Game loads in 2-3 seconds
- Tap any red circles (lives) to test
- Tap white lines when they appear
- Score increases by 10 per line

**Controls:**
- Tap/tap lines to destroy them
- Lose life if line completes without being tapped
- Game over at 0 lives

---

## 🔑 Key Commands Cheat Sheet

```bash
# Build APK
./gradlew android:assembleDebug

# Build + Install + Run (all in one)
./gradlew android:installDebug
./gradlew android:run

# Build Release APK (optimized)
./gradlew android:assembleRelease

# View build logs
./gradlew android:assembleDebug --info

# Clean build
./gradlew clean android:assembleDebug
```

---

## 💾 Backup Your APK

After first successful build:
```bash
# Copy to safe location
cp android/build/outputs/apk/debug/android-debug.apk ~/arrows-backup.apk

# Or share with others
# File: android/build/outputs/apk/debug/android-debug.apk (~30 MB)
```

---

## 📋 Checklist Before Building

- [ ] Extracted arrows-libgdx-project.zip
- [ ] `java -version` shows 11+
- [ ] Inside project directory: `cd arrows-libgdx-project`
- [ ] Read this file
- [ ] Ready to run: `./gradlew android:assembleDebug`

---

## 🎯 Goal

You will have:
✅ Fully working Android APK
✅ Ready to install on any phone (Android 5.1+)
✅ Can customize and rebuild anytime
✅ Same assets as original Unity version

---

## Still Need Help?

1. **Java Issue?** Install from https://adoptopenjdk.net
2. **Build fails?** Run: `./gradlew --refresh-dependencies`
3. **Device issue?** Check `adb devices` output
4. **Gradle error?** Check: `BUILD_GUIDE.md` in the project

---

**Ready? Run this:**
```bash
cd arrows-libgdx-project
./gradlew android:assembleDebug
```

**Your APK will be at:**
```
android/build/outputs/apk/debug/android-debug.apk
```

Enjoy! 🎉
