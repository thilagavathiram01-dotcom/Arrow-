# 🚀 Build APK in 2 Minutes

## SIMPLEST METHOD - Use the Build Script

### macOS/Linux
```bash
unzip arrows-libgdx-project.zip
cd arrows-libgdx-project
bash build-apk.sh
```

### Windows
```bash
unzip arrows-libgdx-project.zip
cd arrows-libgdx-project
build-apk.bat
```

**That's it!** The script does everything automatically.

---

## ✅ What the Script Does

1. ✓ Checks Java version
2. ✓ Cleans old builds
3. ✓ Downloads dependencies (first time only)
4. ✓ Compiles Kotlin to Android APK
5. ✓ Signs the APK
6. ✓ Shows you where the file is

---

## 📍 Your APK Location

After the script finishes:

```
android/build/outputs/apk/debug/android-debug.apk
```

**File size:** ~30 MB (debug version)

---

## ⏱️ Build Time

- **First build**: 3-5 minutes (downloads dependencies)
- **Subsequent builds**: 30-60 seconds

---

## 📱 Install on Phone

### Option 1: Auto-Install (Fastest)
```bash
./gradlew android:installDebug android:run
```
Game launches automatically!

### Option 2: Manual
1. Copy APK to phone via USB/email
2. Open file manager on phone
3. Tap the APK file
4. Tap "Install"

### Option 3: ADB Command
```bash
adb install android/build/outputs/apk/debug/android-debug.apk
```

---

## ✅ Requirements

- Java 11+ (check: `java -version`)
- That's all! Gradle handles everything

---

## 🐛 If Something Goes Wrong

### "Java not found"
Install JDK 11+: https://adoptopenjdk.net

### "Build hangs"
```bash
./gradlew --stop
bash build-apk.sh  # Try again
```

### "Network error"
Gradle needs internet to download dependencies. Check your connection.

---

## 🎯 You're Ready!

Run this now:

**macOS/Linux:**
```bash
unzip arrows-libgdx-project.zip && cd arrows-libgdx-project && bash build-apk.sh
```

**Windows:**
```bash
unzip arrows-libgdx-project.zip && cd arrows-libgdx-project && build-apk.bat
```

**Your APK will be ready in 3-5 minutes!** 🎉
