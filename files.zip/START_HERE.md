# 🎮 Arrows Game - Kotlin + LibGDX Complete Build

## ✨ What You're Getting

A **fully working, buildable Kotlin + LibGDX version** of the Arrows game with:

✅ **Complete Source Code** - All game logic in Kotlin  
✅ **Multi-Platform Support** - Desktop (LWJGL3) + Android  
✅ **Command-Line Build** - No IDE required (but works with any IDE)  
✅ **Full Documentation** - 5 guides included  
✅ **Ready-to-Extend** - Clean architecture for adding features  
✅ **Same Assets** - Compatible with your original PNG/audio files  

---

## 🚀 Quick Start (5 Minutes)

### 1. Extract the ZIP
```bash
unzip arrows-libgdx-project.zip
cd arrows-libgdx-project
```

### 2. Run Desktop Version
```bash
# macOS/Linux
./gradlew desktop:run

# Windows
gradlew.bat desktop:run
```

**That's it!** The game launches in ~30 seconds.

---

## 📁 What's Included

```
arrows-libgdx-project/
├── core/                    # Game logic (shared by all platforms)
│   └── src/main/kotlin/com/arrows/game/
│       ├── ArrowsGame.kt   # Main game class
│       ├── managers/       # StateManager, LivesManager, etc.
│       ├── entities/       # Line entity with collision
│       └── systems/        # LineManager (spawning system)
│
├── desktop/                 # Desktop launcher (LWJGL3)
├── android/                 # Android launcher + resources
│   └── assets/             # Place your sounds/textures here
│
├── README.md               # Full documentation
├── QUICK_START.md          # This guide
├── BUILD_GUIDE.md          # Detailed build for all platforms
├── DEVELOPMENT.md          # Code architecture & extending
│
├── Makefile                # Easy build commands
├── gradlew / gradlew.bat   # Gradle wrapper (no setup needed)
└── build.gradle            # Build configuration
```

---

## 📚 Documentation Included

| File | Purpose |
|------|---------|
| **QUICK_START.md** | ← Start here (you are here) |
| **README.md** | Full feature list & architecture |
| **BUILD_GUIDE.md** | Detailed build for Desktop/Android/Release |
| **DEVELOPMENT.md** | Code guide for extending the game |
| **android/assets/README.md** | How to add your own assets |

---

## 🎯 Common Tasks

### Run Desktop Version
```bash
./gradlew desktop:run
```

### Build Android APK (for testing on phone)
```bash
./gradlew android:assembleDebug
# Output: android/build/outputs/apk/debug/android-debug.apk
```

### Install on Connected Android Device
```bash
# Prerequisites: USB debugging enabled, device connected
./gradlew android:installDebug android:run
```

### Build Release APK (for distribution)
```bash
./gradlew android:assembleRelease
# Output: android/build/outputs/apk/release/android-release.apk
```

### Using Make (if available)
```bash
make run              # Run desktop
make android          # Build debug APK
make install          # Install on device
make release-apk      # Build release APK
make help             # See all commands
```

---

## 🎨 Adding Your Assets

### Audio Files
Place in `android/assets/sounds/`:
- `click.wav` - Sound when line is tapped
- `gameover.wav` - Game over sound
- `background.mp3` - Background music

### Texture Files
Place in `android/assets/textures/`:
- Any PNG or JPG files

### Level Data
Place in `android/assets/data/`:
- JSON configuration files

**Full guide**: See `android/assets/README.md`

---

## 🛠️ System Requirements

### All Platforms
- **Java 11+** - [Download](https://adoptopenjdk.net)
- That's it! Gradle downloads everything else

### Desktop Only
- ✓ Works on Windows, macOS, Linux

### Android Only
- Optional: **Android SDK** (only if you want to test on phone)
- Optional: **Android Studio** (easier development, not required)

### Check Your Java
```bash
java -version
# Should show: version "11" or higher
```

---

## 🎮 Game Features

**Gameplay**
- Lines spawn from screen edges
- Tap/click lines before they disappear
- 10 points per line destroyed
- 3 lives per game
- Game over when all lives lost

**Code Highlights**
- ✅ State management (menu → playing → game over)
- ✅ Lives tracking with invulnerability frames
- ✅ Line spawning with random properties
- ✅ Collision detection (point-to-line math)
- ✅ Audio system (extensible)
- ✅ Input handling (touch/click)

---

## 📊 Project Structure (Architecture)

```
Game Loop (ArrowsGame.kt)
    ├── StateManager    → Game state (MENU/PLAYING/PAUSED/GAME_OVER)
    ├── LivesManager    → Player lives (1-3)
    ├── LineManager     → Spawn system
    ├── AudioManager    → Sound effects
    ├── InputManager    → Touch/click detection
    └── Line Entities   → Rendered, animated, clickable
```

---

## ❓ Troubleshooting

### "Java not found"
```bash
# Install JDK 11+
# Verify: java -version
```

### "Permission denied: ./gradlew"
```bash
chmod +x gradlew
```

### Build hangs or is slow first time
- ⏳ First build downloads all dependencies (10-20 min)
- Subsequent builds are faster (30 sec - 2 min)
- Go grab coffee ☕

### Android build fails
```bash
# Refresh dependencies
./gradlew --refresh-dependencies

# Set ANDROID_HOME if needed
export ANDROID_HOME=$HOME/Library/Android/sdk  # macOS
export ANDROID_HOME=~/Android/Sdk              # Linux
```

### APK too large
- Remove debug symbols: `android:assembleRelease`
- Enable ProGuard: See `BUILD_GUIDE.md`

---

## 🚀 Next Steps

### Beginner
1. ✅ Extract ZIP
2. ✅ Run: `./gradlew desktop:run`
3. ✅ Play the game!
4. ✅ Read `README.md` for features

### Intermediate
1. ✅ Build Android APK: `./gradlew android:assembleDebug`
2. ✅ Add your assets to `android/assets/`
3. ✅ Read `DEVELOPMENT.md` for code guide
4. ✅ Modify game logic in `core/src/main/kotlin/`

### Advanced
1. ✅ Build release APK: `./gradlew android:assembleRelease`
2. ✅ Create keystore for signing
3. ✅ Publish to Play Store
4. ✅ See `BUILD_GUIDE.md` for detailed steps

---

## 📱 Platform-Specific Notes

### Desktop
- Runs on any OS with Java 11+
- No mobile emulator needed
- Perfect for development

### Android Debug
- Quick testing on real device
- Includes debug info
- Good for development

### Android Release
- Optimized, smaller APK
- Signed for distribution
- Ready for Play Store

---

## 🎓 Learning Resources

**Inside the Project**
- `DEVELOPMENT.md` - Code architecture
- `core/src/main/kotlin/` - Well-commented source code
- `android/assets/README.md` - Asset management

**External Resources**
- LibGDX Docs: https://libgdx.com/wiki/
- Kotlin Guide: https://kotlinlang.org/docs/
- Android Dev: https://developer.android.com/

---

## 💡 Tips

- **First build is slow**: Download all dependencies once, then fast
- **Use Make**: If you have `make`, commands are shorter
- **Keep `gradlew` permissions**: `chmod +x gradlew` on Linux/macOS
- **Gradle daemon**: Runs in background, speeds up builds
- **Desktop for dev**: Test changes quickly on desktop before APK

---

## ✅ Checklist: You're Ready If

- [ ] Java 11+ installed: `java -version`
- [ ] Unzipped the project
- [ ] Can run: `./gradlew desktop:run`
- [ ] Game window opens
- [ ] You can tap lines in the game

---

## 🐛 Got Issues?

1. **Check Java**: `java -version` → must be 11+
2. **Clear cache**: `./gradlew clean`
3. **Refresh deps**: `./gradlew --refresh-dependencies`
4. **Read logs**: Build output has error details
5. **Check README.md**: Full troubleshooting section

---

## 📝 File Sizes

| File | Size | Time to Build |
|------|------|---------------|
| Desktop JAR | ~50 MB | 30-60 sec |
| Android APK (debug) | ~30 MB | 2-5 min |
| Android APK (release) | ~15 MB | 3-7 min |

---

## 🎉 You're All Set!

Extract and run:
```bash
unzip arrows-libgdx-project.zip
cd arrows-libgdx-project
./gradlew desktop:run
```

**The game will launch in ~30 seconds! 🚀**

For more info, read the included documentation files.

---

**Questions?** Check the docs:
- `README.md` - Full documentation
- `BUILD_GUIDE.md` - Build details
- `DEVELOPMENT.md` - Code guide
